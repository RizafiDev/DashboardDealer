<?php

namespace App\Filament\Resources\StokMobilResource\Pages;

use App\Filament\Resources\StokMobilResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateStokMobil extends CreateRecord
{
    protected static string $resource = StokMobilResource::class;
}
