<?php

namespace App\Filament\Resources\MerekResource\Pages;

use App\Filament\Resources\MerekResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateMerek extends CreateRecord
{
    protected static string $resource = MerekResource::class;
}
