<?php

namespace App\Filament\Resources\AkunKaryawanResource\Pages;

use App\Filament\Resources\AkunKaryawanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAkunKaryawan extends CreateRecord
{
    protected static string $resource = AkunKaryawanResource::class;
}
